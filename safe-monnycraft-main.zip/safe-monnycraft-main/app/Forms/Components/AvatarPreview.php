<?php

namespace App\Forms\Components;

use Filament\Forms\Components\Field;

class AvatarPreview extends Field
{
    protected string $view = 'forms.components.avatar-preview';
}
