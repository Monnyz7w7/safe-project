<div>
    {{ $this->createAction }}

    <x-filament-actions::modals />
</div>
