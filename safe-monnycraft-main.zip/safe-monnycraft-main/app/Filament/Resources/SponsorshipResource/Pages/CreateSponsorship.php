<?php

namespace App\Filament\Resources\SponsorshipResource\Pages;

use App\Filament\Resources\SponsorshipResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateSponsorship extends CreateRecord
{
    protected static string $resource = SponsorshipResource::class;
}
