<?php

namespace App\Infolists\Components;

use Filament\Infolists\Components\Entry;

class ReportedUserWithAvatar extends Entry
{
    protected string $view = 'infolists.components.reported-user-with-avatar';
}
