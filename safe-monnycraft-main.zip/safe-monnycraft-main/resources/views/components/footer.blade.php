<footer class="bg-white">
    <div class="mx-auto max-w-7xl px-6 py-12 lg:px-8">
        <div>
            <p class="text-center text-xs leading-5 text-gray-500">&copy; {{ date('Y') . ' ' . config('app.name') }}. All rights reserved.</p>
        </div>
    </div>
</footer>
