@props([
    'message' => 'No result found'
])

<div {{ $attributes->merge([
    'class' => 'relative block w-full rounded-lg border-2 border-dashed border-gray-300 p-12 text-center'
]) }}>
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"  class="mx-auto h-12 w-12 text-gray-400">
        <path fill-rule="evenodd" d="m5.965 4.904 9.131 9.131a6.5 6.5 0 0 0-9.131-9.131Zm8.07 10.192L4.904 5.965a6.5 6.5 0 0 0 9.131 9.131ZM4.343 4.343a8 8 0 1 1 11.314 11.314A8 8 0 0 1 4.343 4.343Z" clip-rule="evenodd" />
    </svg>
    <span class="mt-2 block text-sm font-semibold text-gray-900">
        {{ $message }}
    </span>
</div>
