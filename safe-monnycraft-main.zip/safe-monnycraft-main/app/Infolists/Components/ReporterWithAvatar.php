<?php

namespace App\Infolists\Components;

use Filament\Infolists\Components\Entry;

class ReporterWithAvatar extends Entry
{
    protected string $view = 'infolists.components.reporter-with-avatar';
}
